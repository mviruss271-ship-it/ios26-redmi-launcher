package com.moosa.ios26launcher

import android.app.role.RoleManager
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(21, 26, 49)
        window.navigationBarColor = android.graphics.Color.rgb(21, 26, 49)
        setContent { GlassLauncher() }
    }
}

private data class LaunchableApp(
    val name: String,
    val packageName: String,
    val icon: Drawable
)

@Composable
private fun GlassLauncher() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<LaunchableApp>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var showAll by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var clock by remember { mutableStateOf(currentClock()) }

    LaunchedEffect(Unit) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = context.packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { info ->
                val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
                if (packageName == context.packageName) return@mapNotNull null
                LaunchableApp(info.loadLabel(context.packageManager).toString(), packageName,
                    info.loadIcon(context.packageManager))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.name.lowercase(Locale.getDefault()) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            clock = currentClock()
            kotlinx.coroutines.delay(30_000)
        }
    }

    val filtered = apps.filter { it.name.contains(query, ignoreCase = true) }
    val background = Brush.linearGradient(
        listOf(Color(0xFF17213D), Color(0xFF354C78), Color(0xFF7A91B5), Color(0xFF202C4C))
    )

    Box(Modifier.fillMaxSize().background(background)) {
        // Soft translucent decorative highlights
        Box(Modifier.offset(x = (-65).dp, y = 170.dp).size(210.dp)
            .blur(55.dp).background(Color(0x667ED8FF), CircleShape))
        Box(Modifier.align(Alignment.BottomEnd).offset(x = 70.dp, y = (-100).dp)
            .size(250.dp).blur(65.dp).background(Color(0x668F8BFF), CircleShape))

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(clock, color = Color.White, fontSize = 43.sp, fontWeight = FontWeight.Light)
                    Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()),
                        color = Color.White.copy(alpha = .82f), fontSize = 15.sp)
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Launcher settings",
                        tint = Color.White, modifier = Modifier.size(25.dp))
                }
            }

            Spacer(Modifier.height(24.dp))
            Surface(
                color = Color.White.copy(alpha = .17f),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, contentDescription = null,
                        tint = Color.White.copy(alpha = .9f))
                    Spacer(Modifier.width(10.dp))
                    androidx.compose.foundation.text.BasicTextField(
                        value = query, onValueChange = { query = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 16.sp),
                        decorationBox = { inner ->
                            Box {
                                if (query.isEmpty()) Text("Search apps", color = Color.White.copy(alpha = .7f))
                                inner()
                            }
                        }
                    )
                }
            }

            Spacer(Modifier.height(23.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (showAll) "App Library" else "Favourites",
                    color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showAll = !showAll; query = "" }) {
                    Text(if (showAll) "Home" else "See all", color = Color.White)
                }
            }

            val visibleApps = if (showAll || query.isNotEmpty()) filtered else filtered.take(12)
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(top = 8.dp, bottom = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(19.dp)
            ) {
                items(visibleApps, key = { it.packageName }) { app ->
                    AppTile(app) {
                        val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
                        if (launch != null) context.startActivity(launch)
                    }
                }
            }

            // Liquid-glass inspired dock
            Surface(
                color = Color.White.copy(alpha = .20f),
                shape = RoundedCornerShape(30.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            ) {
                Row(
                    Modifier.padding(horizontal = 13.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dockApps = apps.filter {
                        val n = it.name.lowercase()
                        n.contains("phone") || n.contains("message") ||
                        n.contains("camera") || n.contains("chrome")
                    }.distinctBy { it.packageName }.take(4)
                    (if (dockApps.size >= 4) dockApps else apps.take(4)).forEach { app ->
                        AppIcon(app, Modifier.size(49.dp)) {
                            context.packageManager.getLaunchIntentForPackage(app.packageName)?.let {
                                context.startActivity(it)
                            }
                        }
                    }
                }
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Glass Launcher") },
                text = {
                    Column {
                        Text("iOS-inspired home screen for your Redmi Note 15 4G.")
                        Spacer(Modifier.height(12.dp))
                        Text("Choose this app as your default Home app to use it as your launcher.")
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showSettings = false
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                val roleManager = context.getSystemService(RoleManager::class.java)
                                if (roleManager.isRoleAvailable(RoleManager.ROLE_HOME) &&
                                    !roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
                                    context.startActivity(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME))
                                }
                            } else {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                            }
                        } catch (_: Exception) {
                            context.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                        }
                    }) { Text("Set as default") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Close") } }
            )
        }
    }
}

@Composable
private fun AppTile(app: LaunchableApp, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        AppIcon(app, Modifier.size(58.dp), onClick)
        Spacer(Modifier.height(6.dp))
        Text(app.name, color = Color.White, fontSize = 11.sp,
            textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun AppIcon(app: LaunchableApp, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bitmap = remember(app.packageName) {
        runCatching { app.icon.toBitmap(144, 144).asImageBitmap() }.getOrNull()
    }
    if (bitmap != null) {
        Image(bitmap, contentDescription = app.name,
            modifier = modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick))
    } else {
        Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .25f))
            .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            Text(app.name.take(1), color = Color.White, fontSize = 22.sp)
        }
    }
}

private fun currentClock(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
