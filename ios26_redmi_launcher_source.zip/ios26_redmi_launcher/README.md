# Glass Launcher — iOS 26-inspired Android launcher

Target device: Xiaomi Redmi Note 15 4G (HyperOS 3)
Package: com.moosa.ios26launcher
Version: 0.1.0

## What this starter build includes
- Registers as an Android HOME launcher.
- Reads launchable apps installed on the device.
- Opens apps when tapped.
- Search field filters installed apps.
- Favourites grid and a translucent dock.
- Clock/date header and a Liquid Glass-inspired gradient UI.
- Button to request the Android default Home role.

## Build an APK
1. Install the latest stable Android Studio.
2. Extract this ZIP.
3. Open the `ios26_redmi_launcher` folder in Android Studio.
4. Allow Gradle sync and install any requested Android SDK components.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location. Transfer it to your Redmi Note 15 4G and install it.
7. Open Glass Launcher and choose **Set as default** in its settings dialog, or select it under Settings > Apps > Default apps > Home app.

## Important limitations in this first prototype
- This is source code, not a prebuilt APK. It must be built with Android Studio.
- App icon placement, drag-and-drop folders, widgets, notification access, lock-screen replacement, and a full system Control Center are not implemented yet.
- Android/HyperOS does not let a normal third-party launcher replace every system surface. The notification shade and lock screen remain controlled by the operating system.
- `QUERY_ALL_PACKAGES` is used so the launcher can list apps for personal sideloaded use. Google Play distribution has additional policy restrictions.
- This project is an independent iOS-inspired design and is not affiliated with Apple.

## Device notes
Xiaomi's published Redmi Note 15 specifications list a 6.77-inch AMOLED display at 2392 × 1080 and up to 120 Hz. The UI uses responsive Compose layouts rather than hard-coded screen coordinates.
